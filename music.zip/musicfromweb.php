<?php
// kuwo://play/?play=MQ==&num=MQ==&musicrid0=TVVTSUNfNTM1ODEyNTc=&name0=pN+k86TKpMCkpKS5pK2kzqSmpL8=&artist0=yNWxvsi60Mc=&album0=WVVSVVlVUkmBN6w4gTesODJuZC5TZXJpZXMgQkVTVEFMQlVNIKTmpOuk5qTqpLqk4IE3rDgy&artistid0=OTk4OQ==&albumid0=NzA0MDE2Mg==&playsource=d2ViwK3G8L/Nu6e2yy0+MjAxNrDmtaXH+tKz
if(empty($_GET['musicrid0'])) {
    echo "缺少参数";
    header("Location: index.html",true,302);
    return;
}
$ID = base64_decode($_GET['musicrid0']);
$ID = str_replace("MUSIC_","",$ID);
header("Location: index.html?musicid=" . $ID,true,302);

?>