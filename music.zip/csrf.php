<?php
if (!empty($_COOKIE['kw_token'])) {
    printf($_COOKIE['kw_token']);
    return;
}
$ch = curl_init();
// curl_setopt($ch, CURLOPT_HTTPHEADER, array("csrf: " . $header, "referer: https://kuwo.cn"));
//kw_token=
$url = "https://www.kuwo.cn";
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 8);
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// 返回 response_header, 该选项非常重要,如果不为 true, 只会获得响应的正文
curl_setopt($ch, CURLOPT_HEADER, 1);
$data = curl_exec($ch);
// 获得响应结果里的：头大小
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
// 根据头大小去获取头信息内容
$header = substr($data, 0, $headerSize);
// curl_close($curl);
// echo json_encode(curl_getinfo($ch));
$headArr = explode("\r\n", $header);
foreach ($headArr as $loop) {
    if (strpos($loop, "Set-Cookie") !== false) {
        $fenhao = strpos($loop, ";") - 1;
        $maohao = strpos($loop, "=");
        if ($fenhao == false) {
            $fenhao = strlen($loop);
        }
        $edengUrl = trim(substr($loop, $maohao + 1, $fenhao - $maohao));
        print_r($edengUrl);
    }
}
curl_close($ch);
setcookie("kw_token", $edengUrl, time()+3600*24*30);
