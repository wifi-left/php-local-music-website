<?php
include("./libs.php");
Header("content-type: text/json", true);
if (empty($_GET['type'])) {
    echo '{"success":"fail","message":"缺少请求参数。","code":1}';
    return;
}
if (empty($_GET['value'])) {
    echo '{"success":"fail","message":"缺少请求参数。","code":1}';
    return;
}
$type = $_GET['type'];
$value = $_GET['value'];
$offset = 0;
$limit = 30;
if (!empty($_GET['offset'])) {
    $offset = $_GET['offset'];
}
if (!empty($_GET['limit'])) {
    $limit = $_GET['limit'];
}
// $url = str_replace("\~", "%7E", $url);
$headers = "";
$value = urlencode($value);
if ($offset < 1) $offset = 1;
if ($limit < 1) $offset = 10;
$offsets = ((int)$offset - 1) * ((int)$limit);
$html = "";
// echo $offsets;
switch ($type) {
    case 'info':
        $result = json_decode('{"data":{"lrclist":[],"songinfo":{}}}');
        $tmp = json_decode(fetchURL("http://music.163.com/api/song/lyric?os=pc&id=$value&lv=-1&kv=-1&tv=-1", false, ""));
        if (empty($tmp->lrc)) {
            echo '{"code":404,"msg":"404 - 此歌曲不存在"}';
            http_response_code(404);
            return;
        }
        $lrcori1 = "";
        $lrctran = "";
        if (!empty($tmp->lrc->lyric))
            $lrcori1 = ($tmp->lrc->lyric);
        if (!empty($tmp->tlyric->lyric))
            $lrctran = ($tmp->tlyric->lyric);
        $lrcori = LRCTOOBJ($lrcori1);
        $lrctrans = LRCTOOBJ($lrctran);
        $lrc = mergeTranslate($lrcori,$lrctrans);

        $song = json_decode(fetchURL("http://music.163.com/api/song/detail/?ids=[$value]", false, ""))->songs[0];
        $line = json_decode('{"id":0,"rid":"0","musicrid":"0","payInfo":{"feeType":{"vip":0}},"artist":"","name":"","album":"","albumid":"","albumId":"","albumpic":"","artistid":"","releaseDate":null,"songName":""}');
        if (!empty($song->name)) {
            $line->name = $song->name;
            $line->songName = $song->name;
        }
        if (!empty($song->id)) {
            $line->rid = $song->id;
            $line->id = $song->id;
            $line->musicrid = "MUSIC_" . $song->id;
        }
        if (!empty($song->fee)) {
            $line->payInfo->feeType->vip = $song->fee;
        }
        if (!empty($song->artists)) {
            $artistname = "";
            $artistid = "";
            for ($j = 0; $j < count($song->artists); $j++) {
                $tmp = $song->artists[$j];
                $artistid = $song->artists[0]->id;
                $artistname = $artistname . ($artistname == "" ? "" : "&") . $tmp->name;
            }
            $line->artist = $artistname;
            $line->artistid = $artistid;
        }
        if (!empty($song->album)) {
            $album = $song->album;
            if (!empty($album->name)) {
                $line->album = $album->name;
            }
            if (!empty($album->id)) {
                $line->albumid = $album->id;
                $line->albumId = $album->id;
            }
            if (!empty($album->picUrl)) {
                $line->albumpic = $album->picUrl;
                $line->pic = $album->picUrl;
            }
            if (!empty($album->publishTime)) {
                $line->releaseDate = timeToTime($album->publishTime);
            }
        }
        $result->data->songinfo = $line;
        $result->data->lrclist = $lrc;
        $html = json_encode($result);
        break;
    case 'suggestKey':
        $text = (fetchURL("https://music.163.com/api/song/enhance/player/url?id=&ids=[$value]&br=320000", false, "s=$value&offset=$offsets&limit=$limit&type=1"));
        $datas = json_decode($text);
        $html = "";
        http_response_code(404);
        break;
    case 'playlist':
        //https://music.163.com/api/playlist/detail?id=$value&limit=$limit&offset=$offset
        $html = "{}";
        http_response_code(404);
        break;
    case 'alarm':

        //https://music.163.com/api/album/$value?limit=$limit&offset=$offset

        $text = (fetchURL("http://music.163.com/api/album/$value?limit=$limit&offset=$offset", false, "s=$value&offset=$offsets&limit=$limit&type=1"));
        if ($text == false) return;

        $json = json_decode($text);
        $result = json_decode('{"musiclist":[]}');
        if (empty($json->album->songs)) {
            echo $text;
            // echo "empty";
            return;
        }
        if (!empty($json->album->size)) {
            $result->total = $json->album->size;
        }
        $songsarr = $json->album->songs;
        for ($i = 0; $i < count($songsarr); $i++) {
            $line = json_decode('{"rid":"0","musicrid":"0","payInfo":{"feeType":{"vip":0}},"artist":"","name":"","album":"","albumid":"","albumpic":"","artistid":"","releaseDate":null,"web_albumpic_short":""}');
            $song = $songsarr[$i];
            if (!empty($song->name)) {
                $line->name = $song->name;
            }
            if (!empty($song->id)) {
                $line->rid = $song->id;
                $line->musicrid = "MUSIC_" . $song->id;
            }
            if (!empty($song->fee)) {
                $line->payInfo->feeType->vip = $song->fee;
            }
            if (!empty($song->artists)) {
                $artistname = "";
                $artistid = "";
                for ($j = 0; $j < count($song->artists); $j++) {
                    $tmp = $song->artists[$j];
                    $artistid = $song->artists[0]->id;
                    $artistname = $artistname . ($artistname == "" ? "" : "&") . $tmp->name;
                }
                $line->artist = $artistname;
                $line->artistid = $artistid;
            }
            if (!empty($song->album)) {
                $album = $song->album;
                if (!empty($album->name)) {
                    $line->album = $album->name;
                }
                if (!empty($album->id)) {
                    $line->albumid = $album->id;
                }
                if (!empty($album->picUrl)) {
                    $line->albumpic = $album->picUrl;
                    $line->pic = $album->picUrl;
                    $line->web_albumpic_short = $album->picUrl;
                }
                if (!empty($album->publishTime)) {
                    $line->releaseDate = timeToTime($album->publishTime);
                }
            }
            $result->musiclist[] = $line;
        }
        $html = json_encode($result);

        //
        break;
    case 'singer':
        //http://music.163.com/api/artist/albums/$value?limit=$limit&offset=$offset
        http_response_code(404);
        $html = "{}";
        break;
    case 'url':
        $text = (fetchURL("https://music.163.com/api/song/enhance/player/url?id=&ids=[$value]&br=320000", false, "s=$value&offset=$offsets&limit=$limit&type=1"));
        $datas = json_decode($text)->data;
        $html = $datas[0]->url;
        if ($html == "" || $html == null) {
            http_response_code(404);
        }
        break;
    case 'search':
        $text = (fetchURL("http://music.163.com/api/search/pc?s=$value&limit=$limit&offset=$offset&type=1", false, "s=$value&offset=$offsets&limit=$limit&type=1"));
        if ($text == false) return;

        $json = json_decode($text);
        $result = json_decode('{"data":{"total":0,"list":[]}}');
        if (empty($json->result->songs)) {
            echo $text;
            // echo "empty";
            return;
        }
        if (!empty($json->result->songCount)) {
            $result->data->total = $json->result->songCount;
        }
        $songsarr = $json->result->songs;
        for ($i = 0; $i < count($songsarr); $i++) {
            $line = json_decode('{"rid":"0","musicrid":"0","payInfo":{"feeType":{"vip":0}},"artist":"","name":"","album":"","albumid":"","albumpic":"","artistid":"","releaseDate":null}');
            $song = $songsarr[$i];
            if (!empty($song->name)) {
                $line->name = $song->name;
            }
            if (!empty($song->id)) {
                $line->rid = $song->id;
                $line->musicrid = "MUSIC_" . $song->id;
            }
            if (!empty($song->fee)) {
                $line->payInfo->feeType->vip = $song->fee;
            }
            if (!empty($song->artists)) {
                $artistname = "";
                $artistid = "";
                for ($j = 0; $j < count($song->artists); $j++) {
                    $tmp = $song->artists[$j];
                    $artistid = $song->artists[0]->id;
                    $artistname = $artistname . ($artistname == "" ? "" : "&") . $tmp->name;
                }
                $line->artist = $artistname;
                $line->artistid = $artistid;
            }
            if (!empty($song->album)) {
                $album = $song->album;
                if (!empty($album->name)) {
                    $line->album = $album->name;
                }
                if (!empty($album->id)) {
                    $line->albumid = $album->id;
                }
                if (!empty($album->picUrl)) {
                    $line->albumpic = $album->picUrl;
                    $line->pic = $album->picUrl;
                }
                if (!empty($album->publishTime)) {
                    $line->releaseDate = timeToTime($album->publishTime);
                }
            }
            $result->data->list[] = $line;
        }
        $html = json_encode($result);
        break;
    default:
        echo '{"success":"fail","message":"未知的参数","code":1}';
        http_response_code(404);
        return;
}

echo $html;
